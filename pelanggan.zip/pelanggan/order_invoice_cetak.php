<?php
include 'header.php';
include '../koneksi.php';

/** @var mysqli $koneksi */

/* =========================
   CEK LOGIN
========================= */

if (!isset($_SESSION['role'])) {

    header("location:../index.php?pesan=belum_login");
    exit;
}

/* =========================
   CEK ROLE KASIR
========================= */

if ($_SESSION['role'] != 'pelanggan') {

    header("location:../index.php?pesan=bukan_pelanggan");
    exit;
}

$id = $_GET['id'];

$order = mysqli_query($koneksi,
    "SELECT orders.*, user.nama
     FROM orders
     JOIN user
     ON orders.user_id = user.user_id
     WHERE orders.orders_id='$id'");

$t = mysqli_fetch_array($order);
?>

<div class="container">

    <div class="col-md-10 col-md-offset-1">

        <center>
            <h2>INVOICE ORDER</h2>
        </center>

        <br><br>

        <!-- DATA ORDER -->
        <table class="table">

            <tr>
                <th>ID Order</th>
                <th>:</th>
                <th><?php echo $t['orders_id']; ?></th>
            </tr>

            <tr>
                <th>Invoice</th>
                <th>:</th>
                <th><?php echo $t['invoice']; ?></th>
            </tr>

            <tr>
                <th>Nama User</th>
                <th>:</th>
                <th><?php echo $t['nama']; ?></th>
            </tr>

            <tr>
                <th>Metode Pembayaran</th>
                <th>:</th>
                <th><?php echo $t['metode_pembayaran']; ?></th>
            </tr>

            <tr>
                <th>Status</th>
                <th>:</th>
                <th><?php echo $t['status']; ?></th>
            </tr>

        </table>

        <!-- DETAIL ORDER -->
        <table class="table table-bordered">

            <tr>
                <th>No</th>
                <th>Produk</th>
                <th>Harga</th>
                <th>Qty</th>
                <th>Subtotal</th>
            </tr>

            <?php
            $no = 1;

            $detail = mysqli_query($koneksi,
                "SELECT order_items.*, produk.nama_produk
                 FROM order_items
                 JOIN produk
                 ON order_items.produk_id = produk.produk_id
                 WHERE order_items.orders_id='$id'");

            while ($d = mysqli_fetch_array($detail)) {
            ?>

            <tr>

                <td>
                    <?php echo $no++; ?>
                </td>

                <td>
                    <?php echo $d['nama_produk']; ?>
                </td>

                <td>
                    Rp <?php echo number_format($d['harga']); ?>
                </td>

                <td>
                    <?php echo $d['qty']; ?>
                </td>

                <td>
                    Rp <?php echo number_format($d['subtotal']); ?>
                </td>

            </tr>

            <?php } ?>

            <!-- TOTAL -->
            <tr>

                <th colspan="4" class="text-right">
                    Total
                </th>

                <th>
                    Rp <?php echo number_format($t['total']); ?>
                </th>

            </tr>

            <!-- PAJAK -->
            <tr>

                <th colspan="4" class="text-right">
                    Pajak
                </th>

                <th>
                    Rp <?php echo number_format($t['pajak']); ?>
                </th>

            </tr>

            <!-- GRAND TOTAL -->
            <tr>

                <th colspan="4" class="text-right">
                    Grand Total
                </th>

                <th>
                    Rp <?php echo number_format($t['total'] + $t['pajak']); ?>
                </th>

            </tr>

        </table>

        <p class="text-center">
            <i>
                "Terima Kasih Sudah Memesan di Toko Kue Fanda 🍰"
            </i>
        </p>

    </div>

</div>
<script type="text/javascript">
    window.print();
</script>
<?php include 'footer.php'; ?>